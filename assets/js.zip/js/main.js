$(document).ready(function(){
	$('.sidenav').sidenav();
	$('.parallax').parallax();
	$('.carousel.carousel-slider').carousel({
		fullWidth: true,
		indicators: true
	});
	//console.log('ok');
});